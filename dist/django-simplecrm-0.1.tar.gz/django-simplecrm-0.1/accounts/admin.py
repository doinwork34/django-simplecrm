from django.contrib import admin
from accounts.models import UserProfile


admin.site.register(UserProfile)
# Register your models here.
